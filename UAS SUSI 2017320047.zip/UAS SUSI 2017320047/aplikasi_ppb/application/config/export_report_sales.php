<?php
// Fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");
// Mendefinisikan nama file ekspor "hasil-export.xls"
header("Content-Disposition: attachment; filename=data.xls");
?>
<?php
include 'analytic_report.php';
?>
<a class="navbar-brand" href="./" style="margin-bottom: 50px;"><img src="<?php echo base_url(); ?>images/testindo_logo.png" alt="Logo"></a>
	
</style></a>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1 style="color:#fff;">A</h1>
                <h1>Report / Summary on Graphs (Inquiry)</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li class="active">table</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="col-md-6">
        <div class="col-md-12">
            <div id="piechart" style="width:100%; height: 100%;"></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="col-md-12">
            <div id="piecharts" style="width:100%; height: 100%;"></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="col-md-12">
            <div id="columnchart_values1" style="width:100%; height: 100%;"></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="col-md-12">
            <div id="columnchart_values" style="width:100%; height: 100%;"></div>
        </div>
    </div>
</div>
<!-- Right Panel -->
<?php
include 'footer.php';
?>