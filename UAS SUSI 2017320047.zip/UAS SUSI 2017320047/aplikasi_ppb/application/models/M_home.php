<?php 
 
class M_home extends CI_Model{
	
	function data_contact(){
		$this->db->where('id_contact', '1');
		return $this->db->get('contact');
	}
	function data_education(){
		return $this->db->get('education');
	}
	function data_expertise(){
		return $this->db->get('expertise');
	}
	function data_interest(){
		return $this->db->get('interest');
	}
	function data_job(){
		$this->db->where('id_job', '1');
		return $this->db->get('job_specialization');
	}
	function data_skills(){
		return $this->db->get('skills');
	}
	function data_user(){
		$this->db->where('id_user', '1');
		return $this->db->get('user');
	}
	function data_work(){
		return $this->db->get('work_experience');
	}
}