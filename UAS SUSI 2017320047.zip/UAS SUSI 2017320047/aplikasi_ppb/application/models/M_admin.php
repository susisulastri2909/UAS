<?php 
 
class M_admin extends CI_Model{

	function data_login($table, $where){
		return $this->db->get_where($table,$where);
	}
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('admin'));
	}
	function data_barang(){
		return $this->db->get('barang');
	}
	function data_barang_lim(){
		$this->db->order_by('id_barang', 'desc');
		$this->db->limit('1');
		return $this->db->get('barang');
	}
	function data_departemen(){
		return $this->db->get('departemen');
	}
	function data_departemen_lim(){
		$this->db->order_by('id_dept', 'desc');
		$this->db->limit('1');
		return $this->db->get('departemen');
	}
	function data_karyawan(){
		return $this->db->get('karyawan');
	}
	function data_karyawan_lim(){
		$this->db->order_by('nik', 'desc');
		$this->db->limit('1');
		return $this->db->get('karyawan');
	}
	function data_pemesanan_order(){
		return $this->db->get('pemesanan_order');
	}
	function data_pemesanan_order_lim(){
		$this->db->order_by('no_order', 'desc');
		$this->db->limit('1');
		return $this->db->get('pemesanan_order');
	}
	function data_penyerahan_barang(){
		return $this->db->get('penyerahan_barang');
	}
	function data_penyerahan_barang_lim(){
		$this->db->order_by('id_penyerahan', 'desc');
		$this->db->limit('1');
		return $this->db->get('penyerahan_barang');
	}
	function data_permintaan(){
		return $this->db->get('permintaan');
	}
	function data_permintaan_lim(){
		$this->db->order_by('id_permintaan', 'desc');
		$this->db->limit('1');
		return $this->db->get('permintaan');
	}
	function data_satuan(){
		return $this->db->get('satuan_barang');
	}
	function data_satuan_lim(){
		$this->db->order_by('id_satuan', 'desc');
		$this->db->limit('1');
		return $this->db->get('satuan_barang');
	}
	function data_supplier(){
		return $this->db->get('supplier');
	}
	function data_supplier_lim(){
		$this->db->order_by('id_supplier', 'desc');
		$this->db->limit('1');
		return $this->db->get('supplier');
	}
	function data_user(){
		return $this->db->get('user');
	}
	function data_user_lim(){
		$this->db->order_by('id_user', 'desc');
		$this->db->limit('1');
		return $this->db->get('user');
	}
	function data_added($where, $table){
		return $this->db->insert($table,$where);
	}
	function data_edit($where,$table){		
		return $this->db->get_where($table,$where);
	}
	function data_updated($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}	
	function data_deleted($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}
	function export(){
		$z = $this->input->post('d1');
		$x = $this->input->post('d2');
		$c = $this->input->post('d');
		if( $c == "Penyerahan"){
			$this->db->where('date_penyerahanorder >=', $z);
			$this->db->where('date_penyerahanorder <=', $x);
			return $this->db->get('penyerahan_barang');
		}
		if( $c == "Pemesanan"){
		    $this->db->where('date_order >=', $z);
			$this->db->where('date_order <=', $x);
			return $this->db->get('penyerahan_barang');
	    }
	}
}