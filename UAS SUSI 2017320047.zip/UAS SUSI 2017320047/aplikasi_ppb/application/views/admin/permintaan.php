<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">TABLE PERMINTAAN</h4>
                        <p class="category">CRUD</p><br>
                        <a href="<?php echo base_url(); ?>admin/add_permintaan" class="btn"><i class="fa fa-plus"></i>Tambah Permintaan</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped">
                            <thead>
                                <th>No.</th>
                                <th>ID Permintaan</th>
                                <th>Tanggal</th>
                                <th>Departemen</th>
                                <th>Karyawan</th>
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($permintaan as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->id_permintaan ?></td>
                                    <td><?php echo $u->Date ?></td>
                                    <td><?php echo $u->id_dept ?></td>
                                     <?php
                                        $q = $this->db->query("SELECT * from karyawan where nik = $u->Nik")->result();
                                        foreach ($q as $i) {
                                            $karyawan = $i->nama_karyawan;
                                        }
                                    ?>
                                    <td><?php echo $karyawan ?></td>
                                    <td>
                                        <a href="<?php echo base_url(); ?>admin/edit_permintaan/<?php echo $u->id_permintaan?>" class="btn"><i class="fa fa-edit"></i>Edit</a>
                                        <a href="<?php echo base_url(); ?>admin/deleted_permintaan/<?php echo $u->id_permintaan?>" class="btn"><i class="fa fa-trash"></i>Hapus</a>
                                    </td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>