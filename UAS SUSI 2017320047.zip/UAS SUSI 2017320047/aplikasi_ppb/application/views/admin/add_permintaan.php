<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Permintaan</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_permintaan" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<?php
										foreach ($permintaan as $u) {
										?>
										<label>ID Permintaan</label>
										<input type="text" class="form-control" name="id_permintaan" id="id_permintaan" value="<?php echo $u->id_permintaan+1; ?>">
									<?php } ?>
										<div class="form-group">
										<label>Tanggal</label>
										<input type="date" class="form-control" name="date" id="date" value="<?php echo date('Y-m-d'); ?>">
										<label>Departemen</label>
										<select name="id_dept" class="form-control">
											<option value="">Pilih</option>
											<?php foreach ($departemen as $u) {?>
											<option value="<?php echo $u->id_dept ?>"><?php echo $u->NamaDepartemen ?></option>	
											<?php } ?>
										</select>
										<label>Karyawan</label>
										<select name="nik" class="form-control">
											<option value="">Pilih</option>
											<?php foreach ($karyawan as $u) {?>
											<option value="<?php echo $u->nik ?>"><?php echo $u->nama_karyawan ?></option>	
											<?php } ?>
										</select>
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Permintaan</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>