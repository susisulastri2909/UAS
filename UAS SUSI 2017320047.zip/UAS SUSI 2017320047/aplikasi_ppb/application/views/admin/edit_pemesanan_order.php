<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit Pemesanan Order</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_pemesanan_order" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>No Order</label>
										<input type="text" class="form-control" name="no_order" id="no_order" value="<?php echo $u->no_order ?>" readonly="">
										<div class="form-group">
										<label>ID Barang</label>
										<input type="text" class="form-control" name="id_barang" id="id_barang" value="<?php echo $u->id_barang ?>">
										<label>Kuantiti Order</label>
										<input type="text" class="form-control" name="qty_order" id="qty_order" value="<?php echo $u->qty_order ?>">
										<label>Satuan</label>
										<select name="id_satuan" class="form-control">
											<?php  
												$q = $this->db->query("SELECT * from satuan_barang where id_satuan = $u->id_satuan")->result();
												foreach ($q as $i) {
													$id_satuan = $i->id_satuan;
													$nama_satuan = $i->nama_satuan;
												}
											?>
											<option value="<?php echo $id_satuan ?>"><?php echo $nama_satuan ?></option>
											<?php foreach ($satuan as $u) {?>
											<option value="<?php echo $u->id_satuan ?>"><?php echo $u->nama_satuan ?></option>	
											<?php } ?>
										</select>
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit Pemesanan Order</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>