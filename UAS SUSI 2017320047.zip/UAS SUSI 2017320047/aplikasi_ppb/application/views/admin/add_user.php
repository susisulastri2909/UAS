<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah User</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_user" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID user</label>
										<?php
										foreach ($user as $u) {
										?>
										<input type="text" class="form-control" name="id_user" id="id_user" value="<?php echo $u->id_user+1; ?>">
										<?php } ?>
										<div class="form-group">
										<label>Username</label>
										<input type="text" class="form-control" name="username" id="username">
										<label>Password</label>
										<input type="text" class="form-control" name="password" id="password">
										<label>Level</label>
										<select class="form-control" name="level" id="level">
											<option value="admin">Admin</option>
											<option value="user">User</option>
										</select>
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah User</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>