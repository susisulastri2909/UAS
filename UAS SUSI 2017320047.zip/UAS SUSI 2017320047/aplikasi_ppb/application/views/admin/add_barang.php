<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Barang</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_barang" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Barang</label>
										<?php
										foreach ($barang as $u) {
										?>
										<input type="text" class="form-control" name="id_barang" id="id_barang" value="<?php echo $u->id_barang+1; ?>">
										<?php } ?>
										<div class="form-group">
										<label>Nama Barang</label>
										<input type="text" class="form-control" name="nama_barang" id="nama_barang">
										<label>Harga Barang</label>
										<input type="text" class="form-control" name="harga_po" id="harga_po">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Barang</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>