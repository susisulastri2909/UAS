<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">TABLE DEPARTEMEN</h4>
                        <p class="category">CRUD</p><br>
                        <a href="<?php echo base_url(); ?>admin/add_departemen" class="btn"><i class="fa fa-plus"></i>Tambah Departemen</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped">
                            <thead>
                                <th>No.</th>
                                <th>Nama Departemen</th>
                                <th>Tools</th>
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($departemen as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->NamaDepartemen ?></td>
                                    <td>
                                        <a href="<?php echo base_url(); ?>admin/edit_departemen/<?php echo $u->id_dept?>" class="btn"><i class="fa fa-edit"></i>Edit</a>
                                        <a href="<?php echo base_url(); ?>admin/deleted_departemen/<?php echo $u->id_dept?>" class="btn"><i class="fa fa-trash"></i>Hapus</a>
                                    </td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>