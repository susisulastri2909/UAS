<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Supplier</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_supplier" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Supplier</label>
										<?php
										foreach ($supplier as $u) {
										?>
										<input type="text" class="form-control" name="id_supplier" id="id_supplier" value="<?php echo $u->id_supplier+1; ?>">
										<?php } ?>
										<div class="form-group">
										<label>Nama Supplier</label>
										<input type="text" class="form-control" name="nama_supplier" id="nama_supplier">
										<label>Alamat</label>
										<input type="text" class="form-control" name="alamat" id="alamat">
										<label>No Tlp</label>
										<input type="text" class="form-control" name="no_tlp" id="no_tlp">
										<label>Email</label>
										<input type="email" class="form-control" name="email" id="email">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Supplier</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>