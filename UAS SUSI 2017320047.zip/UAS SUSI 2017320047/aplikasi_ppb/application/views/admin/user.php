<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">TABLE USER</h4>
                        <p class="category">CRUD</p><br>
                        <a href="<?php echo base_url(); ?>admin/add_user" class="btn"><i class="fa fa-plus"></i>Tambah User</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped">
                            <thead>
                                <th>No.</th>
                                <th>ID user</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Level</th>
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($user as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->id_user ?></td>
                                    <td><?php echo $u->username ?></td>
                                    <td><?php echo $u->password ?></td>
                                    <td><?php echo $u->level ?></td>
                                    <td>
                                        <a href="<?php echo base_url(); ?>admin/edit_user/<?php echo $u->id_user?>" class="btn"><i class="fa fa-edit"></i>Edit</a>
                                        <a href="<?php echo base_url(); ?>admin/deleted_user/<?php echo $u->id_user?>" class="btn"><i class="fa fa-trash"></i>Hapus</a>
                                    </td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>