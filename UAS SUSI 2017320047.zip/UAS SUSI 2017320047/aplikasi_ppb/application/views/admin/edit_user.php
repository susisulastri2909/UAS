<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit User</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_user" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID user</label>
										<input type="text" class="form-control" name="id_user" id="id_user" value="<?php echo $u->id_user ?>" readonly="">
										<div class="form-group">
										<label>Username</label>
										<input type="text" class="form-control" name="username" id="username" value="<?php echo $u->username ?>">
										<label>Password</label>
										<input type="text" class="form-control" name="password" id="password" value="<?php echo $u->password ?>">
										<label>Level</label>
										<select class="form-control" name="level" id="level">
											<option value="<?php echo $u->level ?>"><?php echo $u->level ?></option>
											<option value="admin">Admin</option>
											<option value="user">User</option>
										</select>
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit User</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>