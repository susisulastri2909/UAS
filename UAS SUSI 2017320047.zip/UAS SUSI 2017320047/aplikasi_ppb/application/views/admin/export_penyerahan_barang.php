<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">CETAK PENYERAHAN BARANG</h4>
                        <p class="category"></p><br>
                    </div>
                    <div class="content table-responsive table-full-width" id="DivIdToPrint">
                        <div style="width: 100%; margin-bottom: 50px;">
                            <h1 style="text-align: center">PT SUPRA FERBINDO FARMA</h1>
                            <div style="float: left; margin-left: 50px;">
                                Tanggal : <?php echo date('Y-m-d'); ?><br>
                                By      : Admin
                            </div>
                            <?php
                                if (isset($d)) { ?>

                            <div style="float: right; margin-right: 50px;">
                                Dari Tanggal : <?php echo $d1 ?><br>
                                Sampai Tanggal : <?php echo $d2 ?>
                            </div>
                            <?php
                                    # code...
                                }
                            ?>
                        </div><br><br>
                        <table class="table table-hover table-striped" style="text-align: left; width: 100%;    ">
                            <thead>
                                <th>No.</th>
                                <th>No. Surat</th>
                                <th>Tgl Pesan</th>
                                <th>Tgl Penyerahan Order</th>
                                <th>No. Order</th>
                                <th>Brg</th>
                                <th>Qty</th>
                                <th>Satuan</th>
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($a as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->id_penyerahan ?></td>
                                    <td><?php echo $u->date_order ?></td>
                                    <td><?php echo $u->date_penyerahanorder ?></td>
                                    <td><?php echo $u->no_order ?></td>
                                    <?php
                                        $e = $this->db->query("SELECT * from barang where id_barang = $u->id_barang")->result();
                                        foreach ($e as $p) {
                                            $brg = $p->nama_barang;
                                        }
                                        $q = $this->db->query("SELECT * from pemesanan_order where no_order = $u->no_order")->result();
                                        foreach ($q as $i) {
                                            $qty = $i->qty_order;
                                            $w = $this->db->query("SELECT* from satuan_barang where id_satuan = $i->id_satuan")->result();
                                            foreach ($w as $o) {
                                                $satuan = $o->nama_satuan;
                                            }
                                        }
                                    ?>
                                    <td><?php echo $brg ?></td>
                                    <td><?php echo $qty ?></td>
                                    <td><?php echo $satuan ?></td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                    <a class="btn btn-info buttons" style="color: #fff; margin-left:60px; background-color: blue;" onclick="printDiv();">CETAK</a>
                            <script>
                                function printDiv() 
                                {

                                  var divToPrint=document.getElementById('DivIdToPrint');

                                  var newWin=window.open('','Print-Window');

                                  newWin.document.open();

                                  newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

                                  newWin.document.close();

                                  setTimeout(function(){newWin.close();},10);

                                }
                            </script>
                            <div class="clearfix"></div><Br><Br>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>