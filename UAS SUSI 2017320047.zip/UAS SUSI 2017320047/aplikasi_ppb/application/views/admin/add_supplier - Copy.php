<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Add Work</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/added_work" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>Year</label>
										<input type="text" class="form-control" name="year_we" id="year_we">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label>Job Position</label>
										<input type="text" class="form-control" name="job_pos_we" id="job_pos_we">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label>Company</label>
										<input type="text" class="form-control" name="company_we" id="company_we">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label>Address Company</label>
										<input type="text" class="form-control" name="address_we" id="address_we">
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Add Work</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>