<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit Departemen</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_departemen" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Departemen</label>
										<input type="text" class="form-control" name="id_dept" id="id_dept" value="<?php echo $u->id_dept ?>" readonly="">
										<div class="form-group">
										<label>Nama Departemen</label>
										<input type="text" class="form-control" name="NamaDepartemen" id="NamaDepartemen" value="<?php echo $u->NamaDepartemen ?>">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit Departemen</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>