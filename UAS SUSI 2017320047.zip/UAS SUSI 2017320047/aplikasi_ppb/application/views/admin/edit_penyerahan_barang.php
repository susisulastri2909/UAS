<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit Penyerahan Barang</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_penyerahan_barang" method="post">
							<?php foreach ($a as $u) { ?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Penyerahan</label>
										<input type="text" class="form-control" name="id_penyerahan" id="id_penyerahan" value="<?php echo $u->id_penyerahan ?>" readonly="">
										<div class="form-group">
										<label>Date Pemesanan</label>
										<input type="date" class="form-control" name="date_order" id="date_order" value="<?php echo $u->date_order ?>">
										<label>ID Barang</label>
										<input type="text" class="form-control" name="id_barang" id="id_barang" value="<?php echo $u->id_barang ?>">
										<label>Date Penyerahan order</label>
										<input type="date" class="form-control" name="date_penyerahanorder" id="date_penyerahanorder" value="<?php echo $u->date_penyerahanorder ?>">
										<label>No Order</label>
										<input type="text" class="form-control" name="no_order" id="no_order" value="<?php echo $u->no_order ?>">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit Penyerahan Barang</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>