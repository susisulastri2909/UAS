<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit Karyawan</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_karyawan" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>NIK Karyawan</label>
										<input type="text" class="form-control" name="nik" id="nik" value="<?php echo $u->nik ?>" readonly="">
										<div class="form-group">
										<label>Nama Karyawan</label>
										<input type="text" class="form-control" name="nama_karyawan" id="nama_karyawan" value="<?php echo $u->nama_karyawan ?>">
										<label>No. Telepon</label>
										<input type="text" class="form-control" name="no_tlp" id="no_tlp" value="<?php echo $u->no_tlp ?>">
										<label>Email</label>
										<input type="email" class="form-control" name="email" id="email" value="<?php echo $u->email ?>">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit Karyawan</button>
							<div class="clearfix"></div>
							<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>