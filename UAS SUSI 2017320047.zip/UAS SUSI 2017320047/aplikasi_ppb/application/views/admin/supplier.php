<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">TABLE SUPPLIER</h4>
                        <p class="category">CRUD</p><br>
                        <a href="<?php echo base_url(); ?>admin/add_supplier" class="btn"><i class="fa fa-plus"></i>Tambah Supplier</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped">
                            <thead>
                                <th>No.</th>
                                <th>ID Supplier</th>
                                <th>Nama Supplier</th>
                                <th>Alamat</th>
                                <th>No Tlp</th>
                                <th>Email</th>
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($supplier as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->id_Supplier ?></td>
                                    <td><?php echo $u->nama_supplier ?></td>
                                    <td><?php echo $u->alamat?></td>
                                    <td><?php echo $u->no_tlp ?></td>
                                    <td><?php echo $u->email ?></td>
                                    <td>
                                        <a href="<?php echo base_url(); ?>admin/edit_supplier/<?php echo $u->id_Supplier?>" class="btn"><i class="fa fa-edit"></i>Edit</a>
                                        <a href="<?php echo base_url(); ?>admin/deleted_supplier/<?php echo $u->id_Supplier?>" class="btn"><i class="fa fa-trash"></i>Hapus</a>
                                    </td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>