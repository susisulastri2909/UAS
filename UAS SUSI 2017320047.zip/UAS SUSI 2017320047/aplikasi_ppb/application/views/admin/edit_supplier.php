<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit Supplier</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_supplier" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Supplier</label>
										<input type="text" class="form-control" name="id_Supplier" id="id_Supplier" value="<?php echo $u->id_Supplier ?>" readonly="">
										<div class="form-group">
										<label>Nama Supplier</label>
										<input type="text" class="form-control" name="nama_supplier" id="nama_supplier" value="<?php echo $u->nama_supplier ?>">
										<label>Alamat</label>
										<input type="text" class="form-control" name="alamat" id="alamat" value="<?php echo $u->alamat ?>">
										<label>No Tlp</label>
										<input type="text" class="form-control" name="no_tlp" id="no_tlp" value="<?php echo $u->no_tlp ?>">
										<label>Email</label>
										<input type="email" class="form-control" name="email" id="email" value="<?php echo $u->email?>">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit Supplier</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>