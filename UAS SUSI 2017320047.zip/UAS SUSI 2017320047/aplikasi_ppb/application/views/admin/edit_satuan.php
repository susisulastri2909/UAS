<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Satuan</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_satuan" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Satuan</label>
										<input type="text" class="form-control" name="id_satuan" id="id_satuan" value="<?php echo $u->id_satuan ?>" readonly="">
										<div class="form-group">
										<label>Nama Satuan</label>
										<input type="text" class="form-control" name="nama_satuan" id="nama_satuan" value="<?php echo $u->nama_satuan ?>">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Satuan</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>