<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Edit Barang</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/update_barang" method="post">
							<?php foreach ($a as $u) {?>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Barang</label>
										<input type="text" class="form-control" name="id_barang" id="id_barang" value="<?php echo $u->id_barang ?>" readonly="">
										<div class="form-group">
										<label>Nama Barang</label>
										<input type="text" class="form-control" name="nama_barang" id="nama_barang" value="<?php echo $u->nama_barang ?>">
										<label>Harga Barang</label>
										<input type="text" class="form-control" name="harga_po" id="harga_po" value="<?php echo $u->harga_po ?>">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Edit Barang</button>
							<div class="clearfix"></div>
						<?php } ?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>