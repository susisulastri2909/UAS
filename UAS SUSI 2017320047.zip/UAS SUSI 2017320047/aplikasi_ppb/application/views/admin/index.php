<?php 
    include 'header.php';
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">WELCOME <?php echo strtoupper($_SESSION['username']) ?> TO THE DASHBOARD</h4><br>
                        <p class="category">This is a welcome message.</p><br><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
    include 'footer.php';
?>