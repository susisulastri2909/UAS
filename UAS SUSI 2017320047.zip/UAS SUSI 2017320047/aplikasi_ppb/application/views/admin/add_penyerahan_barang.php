<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Penyerahan Barang</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_penyerahan_barang" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Penyerahan Barang</label>
										<?php
										foreach ($penyerahan_barang as $u) {
										?>
										<input type="text" class="form-control" name="id_penyerahan" id="id_penyerahan" value="<?php echo $u->id_penyerahan+1; ?>">
										<?php } ?>
										<div class="form-group">
										<label>Date Pemesanan</label>
										<input type="date" class="form-control" name="date_penyerahanorder" id="date_penyerahanorder" value="<?php echo date('Y-m-d') ?>">
										<div class="form-group">
										<label>No Order</label>
										<select name="no_order" class="form-control">
											<option value="">Pilih</option>
											<?php foreach ($pemesanan_order  as $u) {?>
											<option value="<?php echo $u->no_order ?>"><?php echo $u->no_order ?></option>	
											<?php } ?>
										</select>
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Penyerahan Barang</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>