<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Pemesanan Order</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_pemesanan_order" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>No Order</label>
										<?php
										foreach ($pemesanan_order as $u) {
										?>
										<input type="text" class="form-control" name="no_order" id="no_order" value="<?php echo $u->no_order+1; ?>">
										<?php } ?>
										<label>Date Order</label>
										<input type="date" class="form-control" name="date_order" id="date_order" value="<?php echo date('Y-m-d'); ?>">
										<div class="form-group">
										<label>Nama Barang</label>
										<select name="id_barang" class="form-control">
											<option value="">Pilih</option>
											<?php foreach ($barang as $u) {?>
											<option value="<?php echo $u->id_barang ?>"><?php echo $u->nama_barang ?></option>	
											<?php } ?>
										</select>
										<label>Kuantiti Order</label>
										<input type="text" class="form-control" name="qty_order" id="qty_order">
										<div class="form-group">
										<label>Satuan</label>
										<select name="id_satuan" class="form-control">
											<option value="">Pilih</option>
											<?php foreach ($satuan as $u) {?>
											<option value="<?php echo $u->id_satuan ?>"><?php echo $u->nama_satuan ?></option>	
											<?php } ?>
										</select>
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Pemesanan Order</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>