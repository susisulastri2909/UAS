<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">TABLE PENYERAHAN BARANG</h4>
                        <p class="category">CRUD</p><br>
                        <a href="<?php echo base_url(); ?>admin/add_penyerahan_barang" class="btn"><i class="fa fa-plus"></i>Tambah Penyerahan Barang</a><br><br>
                        <h5>Find & Export</h5>
                        <form action="<?php echo base_url(); ?>admin/exp" method="post">
                            <input type="date" name="d1">
                            <input type="date" name="d2">
                            <select name="d">
                                <option value="Penyerahan">Penyerahan</option>
                                <option value="Pemesanan">Pemesanan</option>
                            </select>
                            <button type="submit">Search</button>
                        </form>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped">
                            <thead>
                                <th>No.</th>
                                <th>Tanggan Pesan</th>
                                <th>Tanggal Penyerahan order</th>
                                <th>Nama Barang</th>
                                <th>Nomor Order</th>
  
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($penyerahan_barang as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->date_order ?></td>
                                    <td><?php echo $u->date_penyerahanorder ?></td>
                                    <?php
                                        $e = $this->db->query("SELECT * from barang where id_barang = $u->id_barang")->result();
                                        foreach ($e as $p) {
                                            $brg = $p->nama_barang;
                                        }
                                        ?>
                                    <td><?php echo $brg ?></td>
                                    <td><?php echo $u->no_order ?></td>
                                    <td>
                                        <a href="<?php echo base_url(); ?>admin/edit_penyerahan_barang/<?php echo $u->id_penyerahan?>" class="btn"><i class="fa fa-edit"></i>Edit</a>
                                        <a href="<?php echo base_url(); ?>admin/deleted_penyerahan_barang/<?php echo $u->id_penyerahan?>" class="btn"><i class="fa fa-trash"></i>Hapus</a>
                                        <a href="<?php echo base_url(); ?>admin/exp_penyerahan_barang/<?php echo $u->id_penyerahan?>" class="btn"><i class="fa fa-trash"></i>Export</a>
                                    </td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>