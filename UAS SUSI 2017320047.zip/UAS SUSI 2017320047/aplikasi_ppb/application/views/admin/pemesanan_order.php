<?php
include 'header.php';
?>
<!-- MAIN CONTENT-->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">TABLE PEMESANAN ORDER</h4>
                        <p class="category">CRUD</p><br>
                        <a href="<?php echo base_url(); ?>admin/add_pemesanan_order" class="btn"><i class="fa fa-plus"></i>Tambah Pemesanan Order</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped">
                            <thead>
                                <th>No.</th>
                                <th>Nomor Order</th>
                                <th>Date Order</th>
                                <th>Nama Barang</th>
                                <th>Kuantiti Order</th>
                                <th>Satuan</th>
                            </thead>
                            <tbody>
                                <?php $no = 1 ; foreach ($pemesanan_order as $u) {?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $u->no_order ?></td>
                                    <td><?php echo $u->date_order ?></td>
                                     <?php
                                        $q = $this->db->query("SELECT * from barang where id_barang = $u->id_barang")->result();
                                        foreach ($q as $b) {
                                            $id_barang = $b->nama_barang;
                                        }
                                    ?>
                                    <td><?php echo $id_barang ?></td>
                                    <td><?php echo $u->qty_order ?></td>
                                    <?php
                                        $q = $this->db->query("SELECT * from satuan_barang where id_satuan = $u->id_satuan")->result();
                                        foreach ($q as $i) {
                                            $id_satuan = $i->nama_satuan;
                                        }
                                    ?>
                                    <td><?php echo $id_satuan ?></td>
                                    <td>
                                        <a href="<?php echo base_url(); ?>admin/edit_pemesanan_order/<?php echo $u->no_order?>" class="btn"><i class="fa fa-edit"></i>Edit</a>
                                        <a href="<?php echo base_url(); ?>admin/deleted_pemesanan_order/<?php echo $u->no_order?>" class="btn"><i class="fa fa-trash"></i>Hapus</a>
                                    </td>
                                </tr>
                                <?php $no++;}   ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>