<?php
	include 'header.php';
?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Tambah Departemen</h4>
					</div>
					<div class="content">
						<form action="<?php echo base_url(); ?>admin/insert_departemen" method="post">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label>ID Departemen</label>
										<?php
										foreach ($departemen as $u) {
										?>
										<input type="text" class="form-control" name="id_dept" id="id_dept" value="<?php echo $u->id_dept+1; ?>">
										<?php } ?>
										<div class="form-group">
										<label>Nama Departemen</label>
										<input type="text" class="form-control" name="NamaDepartemen" id="NamaDepartemen">
									</div>
									</div>
								</div>
							</div>
							<button type="submit" name="sub" id="sub" class="btn btn-info btn-fill pull-right">Tambah Departemen</button>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'footer.php';
?>