<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Admin extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('M_admin');
	}
	public function login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
 		
		$where = array(
			'username' => $username,
			'password' => $password
			);


		$cek = $this->M_admin->data_login("user",$where)->num_rows();
		if($cek > 0){
			$query = $this->db->get_where('user', $where);

		    if( $query->num_rows() > 0) {
			    $result = $query->result(); //or $query->result_array() to get an array
			    foreach( $result as $row )
			    {
			         $data_session = array(
										 'username' => "$row->username",
										 'level' => "$row->level"
										  );
			    }
			}    
			
			$data = $this->session->set_userdata($data_session);
			if (isset($data)) {
				$_SESSION['username'] = $username;
				$_SESSION['level'] = $row->level;
			}
			// $this->load->view('admin/index',$data);
			redirect(base_url("admin/dashboard",$data));
 
		}else{
			$data = array(
						'salah' => "Username atau password salah",
						'title' => "Login Admin - Testindo"
						);
			$this->load->view('admin/login',$data);

		};
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url('admin'));
	}
	public function index(){
		$this->load->view('admin/login');
	}
	public function dashboard(){
		$this->load->view('admin/index');
	}
	public function barang(){
		$data = array(
			'title' => "Barang -  PPB"
		);
		$data['barang'] = $this->M_admin->data_barang()->result();
		$this->load->view('admin/barang', $data);
	}
	public function departemen(){
		$data = array(
			'title' => "Departemen -  PPB"
		);
		$data['departemen'] = $this->M_admin->data_departemen()->result();
		$this->load->view('admin/departemen', $data);
	}
	public function karyawan(){
		$data = array(
			'title' => "Karyawan -  PPB"
		);
		$data['karyawan'] = $this->M_admin->data_karyawan()->result();
		$this->load->view('admin/karyawan', $data);
	}
	public function pemesanan_order(){
		$data = array(
			'title' => "Pemesanan Order -  PPB"
		);
		$data['pemesanan_order'] = $this->M_admin->data_pemesanan_order()->result();
		$this->load->view('admin/pemesanan_order', $data);
	}
	public function penyerahan_barang(){
		$data = array(
			'title' => "Penyerahan Barang -  PPB"
		);
		$data['penyerahan_barang'] = $this->M_admin->data_penyerahan_barang()->result();
		$this->load->view('admin/penyerahan_barang', $data);
	}
	public function permintaan(){
		$data = array(
			'title' => "Permintaan -  PPB"
		);
		$data['permintaan'] = $this->M_admin->data_permintaan()->result();
		$this->load->view('admin/permintaan', $data);
	}
	public function satuan(){
		$data = array(
			'title' => "Satuan -  PPB"
		);
		$data['satuan'] = $this->M_admin->data_satuan()->result();
		$this->load->view('admin/satuan', $data);
	}
	public function supplier(){
		$data = array(
			'title' => "Pemesanan Order -  PPB"
		);
		$data['supplier'] = $this->M_admin->data_supplier()->result();
		$this->load->view('admin/supplier', $data);
	}
	public function user(){
		$data = array(
			'title' => "User -  PPB"
		);
		$data['user'] = $this->M_admin->data_user()->result();
		$this->load->view('admin/user', $data);
	}
	public function add_barang(){
		$data = array(
			'title' => "Tambah Barang -  PPB"
		);
		$data['barang'] = $this->M_admin->data_barang_lim()->result();
		$this->load->view('admin/add_barang', $data);
	}
	public function add_departemen(){
		$data = array(
			'title' => "Tambah Departemen -  PPB"
		);
		$data['departemen'] = $this->M_admin->data_departemen_lim()->result();
		$this->load->view('admin/add_departemen', $data);
	}
	public function add_karyawan(){
		$data = array(
			'title' => "Tambah Karyawan -  PPB"
		);
		$data['karyawan'] = $this->M_admin->data_karyawan_lim()->result();
		$this->load->view('admin/add_karyawan', $data);
	}
	public function add_pemesanan_order(){
		$data = array(
			'title' => "Tambah Pemesanan Order -  PPB"
		);
		$data['pemesanan_order'] = $this->M_admin->data_pemesanan_order_lim()->result();
		$data['barang'] = $this->M_admin->data_barang()->result();
		$data['satuan'] = $this->M_admin->data_satuan()->result();
		$this->load->view('admin/add_pemesanan_order', $data);
	}
	public function add_penyerahan_barang(){
		$data = array(
			'title' => "Tambah Penyerahan Barang -  PPB"
		);
		$data['pemesanan_order'] = $this->M_admin->data_pemesanan_order()->result();
		$data['penyerahan_barang'] = $this->M_admin->data_penyerahan_barang_lim()->result();
		$data['barang'] = $this->M_admin->data_barang()->result();
		$this->load->view('admin/add_penyerahan_barang', $data);
	}
	public function add_permintaan(){
		$data = array(
			'title' => "Tambah Permintaan -  PPB"
		);
		$data['departemen'] = $this->M_admin->data_departemen()->result();
		$data['karyawan'] = $this->M_admin->data_karyawan()->result();
		$data['permintaan'] = $this->M_admin->data_permintaan_lim()->result();
		$this->load->view('admin/add_permintaan', $data);

	}
	public function add_satuan(){
		$data = array(
			'title' => "Tambah Satuan -  PPB"
		);
		$data['satuan'] = $this->M_admin->data_satuan_lim()->result();
		$this->load->view('admin/add_satuan', $data);
	}
	public function add_supplier(){
		$data = array(
			'title' => "Tambah Supplier -  PPB"
		);
		$data['satuan'] = $this->M_admin->data_satuan_lim()->result();
		$this->load->view('admin/add_supplier', $data);
	}
	public function add_user(){
		$data = array(
			'title' => "Tambah User -  PPB"
		);
		$data['user'] = $this->M_admin->data_user_lim()->result();
		$this->load->view('admin/add_user', $data);
	}
	public function edit_barang($id){
		$where = array('id_barang' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'barang')->result();
		$this->load->view('admin/edit_barang',$data);
	}
	public function edit_departemen($id){
		$where = array('id_dept' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'departemen')->result();
		$this->load->view('admin/edit_departemen',$data);
	}
	public function edit_karyawan($id){
		$where = array('nik' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'karyawan')->result();
		$this->load->view('admin/edit_karyawan',$data);
	}
	public function edit_pemesanan_order($id){
		$where = array('no_order' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'pemesanan_order')->result();
		$data['satuan'] = $this->M_admin->data_satuan()->result();
		$this->load->view('admin/edit_pemesanan_order',$data);
	}
	public function edit_penyerahan_barang($id){
		$where = array('id_penyerahan' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'penyerahan_barang')->result();
		$this->load->view('admin/edit_penyerahan_barang',$data);
	}
	public function edit_permintaan($id){
		$where = array('id_permintaan' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'permintaan')->result();
		$this->load->view('admin/edit_permintaan',$data);
	}
	public function edit_satuan($id){
		$where = array('id_satuan' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'satuan_barang')->result();
		$this->load->view('admin/edit_satuan',$data);
	}
	public function edit_supplier($id){
		$where = array('id_supplier' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'supplier')->result();
		$this->load->view('admin/edit_supplier',$data);
	}
	public function edit_user($id){
		$where = array('id_user' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'user')->result();
		$this->load->view('admin/edit_user',$data);
	}
 	public function insert_barang(){
		$id_barang = $this->input->post('id_barang');
		$nama_barang = $this->input->post('nama_barang');
		$harga_po = $this->input->post('harga_po');

		$data = array(
			'id_barang' => $id_barang,
			'nama_barang' => $nama_barang,
			'harga_po' => $harga_po
			);

		$this->M_admin->data_added($data,'barang');
		redirect('admin/barang');
	}
	public function insert_departemen(){
		$id_dept = $this->input->post('id_dept');
		$NamaDepartemen = $this->input->post('NamaDepartemen');

		$data = array(
			'id_dept' => $id_dept,
			'NamaDepartemen' => $NamaDepartemen
			);

		$this->M_admin->data_added($data,'departemen');
		redirect('admin/departemen');
	}
	public function insert_karyawan(){
		$nik = $this->input->post('nik');
		$nama_karyawan = $this->input->post('nama_karyawan');
		$no_tlp = $this->input->post('no_tlp');
		$email = $this->input->post('email');

		$data = array(
			'nik' => $nik,
			'nama_karyawan' => $nama_karyawan,
			'no_tlp' => $no_tlp,
			'email' => $email
			);

		$this->M_admin->data_added($data,'karyawan');
		redirect('admin/karyawan');
	}
	public function insert_pemesanan_order(){
		$no_order = $this->input->post('no_order');
		$date_order = $this->input->post('date_order');
		$id_barang = $this->input->post('id_barang');
		$qty_order = $this->input->post('qty_order');
		$id_satuan = $this->input->post('id_satuan');

		$data = array(
			'no_order' => $no_order,
			'date_order' => $date_order,
			'id_barang' => $id_barang,
			'qty_order' => $qty_order,
			'id_satuan' => $id_satuan
			);

		$this->M_admin->data_added($data,'pemesanan_order');
		redirect('admin/pemesanan_order');
	}
	public function insert_penyerahan_barang(){
		$id_penyerahan = $this->input->post('id_penyerahan');
		$date_penyerahanorder = $this->input->post('date_penyerahanorder');
		$no_order = $this->input->post('no_order');

		// connect to the server
		$conn = new mysqli('localhost', 'root', '', 'ppb');
		$row = $conn->query("SELECT * FROM pemesanan_order where no_order =  '$no_order'")->fetch_array();
		$id_barang = $row["id_barang"];
		$date_order = $row["date_order"];
		


		$data = array(
			'id_penyerahan' => $id_penyerahan,
			'date_order' => $date_order,
			'id_barang' => $id_barang,
			'date_penyerahanorder' => $date_penyerahanorder,
			'no_order' => $no_order
			);

		$this->M_admin->data_added($data,'penyerahan_barang');
		redirect('admin/penyerahan_barang');
	}
	public function insert_permintaan(){
		$id_permintaan = $this->input->post('id_permintaan');
		$date = $this->input->post('date');
		$id_dept = $this->input->post('id_dept');
		$nik = $this->input->post('nik');

		$data = array(
			'id_permintaan' => $id_permintaan,
			'date' => $date,
			'id_dept' => $id_dept,
			'nik' => $nik
			);

		$this->M_admin->data_added($data,'permintaan');
		redirect('admin/permintaan');
	}
	public function insert_satuan(){
		$id_satuan = $this->input->post('id_satuan');
		$nama_satuan = $this->input->post('nama_satuan');

		$data = array(
			'id_satuan' => $id_satuan,
			'nama_satuan' => $nama_satuan
			);

		$this->M_admin->data_added($data,'satuan_barang');
		redirect('admin/satuan');
	}
	public function insert_supplier(){
		$id_Supplier = $this->input->post('id_Supplier');
		$nama_supplier = $this->input->post('nama_supplier');
		$alamat = $this->input->post('alamat');
		$no_tlp = $this->input->post('no_tlp');
		$email = $this->input->post('email');

		$data = array(
			'id_Supplier' => $id_Supplier,
			'nama_supplier' => $nama_supplier,
			'alamat' => $alamat,
			'no_tlp' => $no_tlp,
			'email' => $email
			);

		$this->M_admin->data_added($data,'supplier');
		redirect('admin/supplier');
	}
	public function insert_user(){
		$id_user = $this->input->post('id_user');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$level = $this->input->post('level');

		$data = array(
			'id_user' => $id_user,
			'username' => $username,
			'password' => $password,
			'level' => $level
			);

		$this->M_admin->data_added($data,'user');
		redirect('admin/user');
	}
	public function update_barang(){
		$id_barang = $this->input->post('id_barang');
		$nama_barang = $this->input->post('nama_barang');
		$harga_po = $this->input->post('harga_po');

		$data = array(
			'id_barang' => $id_barang,
			'nama_barang' => $nama_barang,
			'harga_po' => $harga_po
			);
		$where = array(
			'id_barang' => $id_barang
		);
		$this->M_admin->data_updated($where,$data,'barang');
		redirect('admin/barang');
	}
	public function update_departemen(){
		$id_dept = $this->input->post('id_dept');
		$NamaDepartemen = $this->input->post('NamaDepartemen');

		$data = array(
			'id_dept' => $id_dept,
			'NamaDepartemen' => $NamaDepartemen
			);
		$where = array(
			'id_dept' => $id_dept
			);
		$this->M_admin->data_updated($where,$data,'departemen');
		redirect('admin/departemen');
	}
	public function update_karyawan(){
		$nik = $this->input->post('nik');
		$nama_karyawan = $this->input->post('nama_karyawan');
		$no_tlp = $this->input->post('no_tlp');
		$email = $this->input->post('email');

		$data = array(
			'nik' => $nik,
			'nama_karyawan' => $nama_karyawan,
			'no_tlp' => $no_tlp,
			'email' => $email
			);
		$where = array(
			'nik' => $nik
			);
		$this->M_admin->data_updated($where,$data,'karyawan');
		redirect('admin/karyawan');
	}
	public function update_pemesanan_order(){
		$no_order = $this->input->post('no_order');
		$date_order = $this->input->post('date_order');
		$id_barang = $this->input->post('id_barang');
		$qty_order = $this->input->post('qty_order');
		$id_satuan = $this->input->post('id_satuan');

		$data = array(
			'date_order' => $date_order,
			'id_barang' => $id_barang,
			'qty_order' => $qty_order,
			'id_satuan' => $id_satuan
			);

		$where = array(
			'no_order' => $no_order
			);
		$this->M_admin->data_updated($where,$data,'pemesanan_order');
		redirect('admin/pemesanan_order');
	}
	public function update_penyerahan_barang(){
		$id_penyerahan = $this->input->post('id_penyerahan');
		$date_order = $this->input->post('date_order');
		$id_barang = $this->input->post('id_barang');
		$date_penyerahanorder = $this->input->post('date_penyerahanorder');
		$no_order = $this->input->post('no_order');

		$data = array(
			'id_penyerahan' => $id_penyerahan,
			'date_order' => $date_order,
			'id_barang' => $id_barang,
			'date_penyerahanorder' => $date_penyerahanorder,
			'no_order' => $no_order
			);
		$where = array(
			'id_penyerahan' => $id_penyerahan
			);
		$this->M_admin->data_updated($where,$data,'penyerahan_barang');
		redirect('admin/penyerahan_barang');
	}
	public function update_permintaan(){
		$id_permintaan = $this->input->post('id_permintaan');
		$date = $this->input->post('date');
		$id_dept = $this->input->post('id_dept');
		$nik = $this->input->post('nik');

		$data = array(
			'id_permintaan' => $id_permintaan,
			'date' => $date,
			'id_dept' => $id_dept,
			'nik' => $nik
			);
		$where = array(
			'id_permintaan' => $id_permintaan
			);
		$this->M_admin->data_updated($where,$data,'permintaan');
		redirect('admin/permintaan');
	}
	public function update_satuan(){
		$id_satuan = $this->input->post('id_satuan');
		$nama_satuan = $this->input->post('nama_satuan');

		$data = array(
			'id_satuan' => $id_satuan,
			'nama_satuan' => $nama_satuan
			);
		$where = array(
			'id_satuan' => $id_satuan
			);
		$this->M_admin->data_updated($where,$data,'satuan_barang');
		redirect('admin/satuan');
	}
	public function update_supplier(){
		$id_Supplier = $this->input->post('id_Supplier');
		$nama_supplier = $this->input->post('nama_supplier');
		$alamat = $this->input->post('alamat');
		$no_tlp = $this->input->post('no_tlp');
		$email = $this->input->post('email');

		$data = array(
			'id_Supplier' => $id_Supplier,
			'nama_supplier' => $nama_supplier,
			'alamat' => $alamat,
			'no_tlp' => $no_tlp,
			'email' => $email
			);
		$where = array(
			'id_Supplier' => $id_Supplier
			);
		$this->M_admin->data_updated($where,$data,'supplier');
		redirect('admin/supplier');
	}
	public function update_user(){
		$id_user = $this->input->post('id_user');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$level = $this->input->post('level');

		$data = array(
			'id_user' => $id_user,
			'username' => $username,
			'password' => $password,
			'level' => $level
			);
		$where = array(
			'id_user' => $id_user
			);
		$this->M_admin->data_updated($where,$data,'user');
		redirect('admin/user');
	}
	public function deleted_barang($id){
		$where = array('id_barang' => $id);
		$this->M_admin->data_deleted($where,'barang');
		redirect('admin/barang');
	}
	public function deleted_departemen($id){
		$where = array('id_dept' => $id);
		$this->M_admin->data_deleted($where,'departemen');
		redirect('admin/departemen');
	}
	public function deleted_education($id){
		$where = array('id_education' => $id);
		$this->M_admin->data_deleted($where,'education');
		redirect('admin/education');
	}
	public function deleted_karyawan($id){
		$where = array('nik' => $id);
		$this->M_admin->data_deleted($where,'karyawan');
		redirect('admin/karyawan');
	}
	public function deleted_permintaan_order($id){
		$where = array('no_order' => $id);
		$this->M_admin->data_deleted($where,'permintaan_order');
		redirect('admin/permintaan_order');
	}
	public function deleted_penyerahan_barang($id){
		$where = array('id_penyerahan' => $id);
		$this->M_admin->data_deleted($where,'penyerahan_barang');
		redirect('admin/penyerahan_barang');
	}
	public function deleted_permintaan($id){
		$where = array('id_permintaan' => $id);
		$this->M_admin->data_deleted($where,'permintaan');
		redirect('admin/permintaan');
	}
	public function deleted_satuan($id){
		$where = array('id_satuan' => $id);
		$this->M_admin->data_deleted($where,'satuan_barang');
		redirect('admin/satuan');
	}
	public function deleted_supplier($id){
		$where = array('id_supplier' => $id);
		$this->M_admin->data_deleted($where,'supplier');
		redirect('admin/supplier');
	}
	public function deleted_user($id){
		$where = array('id_user' => $id);
		$this->M_admin->data_deleted($where,'user');
		redirect('admin/user');
	}
	public function exp_penyerahan_barang($id){
		$where = array('id_penyerahan' => $id);
		$data['a'] = $this->M_admin->data_edit($where,'penyerahan_barang')->result();
		$this->load->view('admin/export_penyerahan_barang',$data);
	}

	public function exp(){
		$z = $this->input->post('d1');
		$x = $this->input->post('d2');
		$c = $this->input->post('d');
		$data = array(
			'd1' => $z,
			'd2' => $x,
			'd' => $c
		);
		$data['a'] = $this->M_admin->export()->result();  
		$this->load->view('admin/export_penyerahan_barang',$data);
	}


}