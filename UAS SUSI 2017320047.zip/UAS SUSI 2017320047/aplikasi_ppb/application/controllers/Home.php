<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('M_home');
	}
	
	public function index()
	{
		$data['contact'] = $this->M_home->data_contact()->result();
		$data['education'] = $this->M_home->data_education()->result();
		$data['expertise'] = $this->M_home->data_expertise()->result();
		$data['interest'] = $this->M_home->data_interest()->result();
		$data['job'] = $this->M_home->data_job()->result();
		$data['skills'] = $this->M_home->data_skills()->result();
		$data['user'] = $this->M_home->data_user()->result();
		$data['work'] = $this->M_home->data_work()->result();
		$this->load->view('index', $data);
	}
	public function resume()
	{
		$data['contact'] = $this->M_home->data_contact()->result();
		$data['education'] = $this->M_home->data_education()->result();
		$data['expertise'] = $this->M_home->data_expertise()->result();
		$data['interest'] = $this->M_home->data_interest()->result();
		$data['job'] = $this->M_home->data_job()->result();
		$data['skills'] = $this->M_home->data_skills()->result();
		$data['user'] = $this->M_home->data_user()->result();
		$data['work'] = $this->M_home->data_work()->result();
		$this->load->view('resume', $data);
	}
}
